from cityscorewebapp.cityscore.cityscore.models import Metric
Metric.objects.filter(id=2).delete()